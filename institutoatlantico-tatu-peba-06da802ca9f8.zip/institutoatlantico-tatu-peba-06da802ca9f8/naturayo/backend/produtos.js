// --- CRUD simples para produtos ---
// Vamos criar uma lista de produtos simples no JavaScript para simular
let produtos = [
  { id: 1, nome: 'Smartphone', preco: 1200 },
  { id: 2, nome: 'Notebook', preco: 3400 },
  { id: 3, nome: 'Fone Bluetooth', preco: 250 }
];// --- Gráfico de Vendas Mensais ---
export const ctx = document.getElementById('salesChart').getContext('2d');
export const vendas = document.getElementById('salesChart').getContext('2d');

